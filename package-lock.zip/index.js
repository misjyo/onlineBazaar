const express = require("express");
// const cors = require("cors");
// const { con } = require("../../../modal/modal");
// const {
//   validate,
// } = require("../../../validation/Admin/shopRegistration/Shopregistration.validation");
const {
  getdata,
} = require("./controller/Admin/shopRegistration/shopRegistration.controller");

const app = express();
const port = 3001;

app.use(express.json());
// app.use(cors());

app.get("/shopregistration", getdata);

app.listen(port, () => {
  console.log("server started = http://localhost:3001");
});
