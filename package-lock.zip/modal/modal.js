const mysql = require("mysql");

const con = mysql.createConnection({
  host: "database-1.cphquvmh92gg.ap-south-1.rds.amazonaws.com", //RDS = end point
  user: "admin",
  password: "12345678",
  database: "Amazonia",
});
con.connect((err) => {
  if (err) {
    return console.log(err.sqlMessage);
  }

  console.log("database connected");
});

module.exports = { con };
