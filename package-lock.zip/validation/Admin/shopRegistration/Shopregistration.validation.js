const joi = require("joi");

//  schema design
const schema = joi.object({
  regno: joi.string().min(1).max(10).required(),

  shopid: joi.string().min(2).max(10).required(),
  shopname: joi.string().min(2).max(20).required(),

  owner: joi.string().min(2).max(10).required(),
  address: joi.string().min(2).max(50).required(),

  city: joi.string().min(2).max(20).required(),

  state: joi.string().min(2).max(20).required(),
  email: joi
    .array()
    .items(joi.string().email().max(20).required())
    .single()
    .required(),
  url: joi.string().min(2).max(20).required(),
  turnover: joi.string().min(2).max(20).required(),
  discription: joi.string().min(2).max(50).required(),
  uploaddocs: joi.string().min(2).max(15).required(),
  status: joi.valid("pending", "activated").required(),

  pincode: joi.string().length(6).required(),

  contact: joi.string().length(10).required(),

  type: joi
    .valid(
      "electronic",
      "statinary",
      "clothing",
      "grocery",
      "footwears",
      "computers",
      "generalstore"
    )
    .required(),
  gst: joi.string().length(10).required(),
});

const validate = async (req, res, next) => {
  const value = await schema.validate(req.body);
  if (value.error) {
    res.send({ error: value.error.details[0] });
  } else {
    next();
  }
};

module.exports = { validate };
