const joi = require("joi");

//  schema design
const schema = joi.object({
 
  offerid:joi.string().min(1).max(10).required(),
  coupancode:string().min(1).max(10).required(),
  fromdate: string().min(1).max(10).required(),
  todate: string().min(1).max(10).required(),
  discountpercentage: string().min(1).max(10).required(),
  flatdiscount:string().min(1).max(10).required(),
  validin: string().min(1).max(10).required(),
  bankoffer: string().min(1).max(10).required(),

});

const validate = async (req, res, next) => {
  const value = await schema.validate(req.body);
  if (value.error) {
    res.send({ error: value.error.details[0] });
  } else {
    next();
  }
};

module.exports = { validate };
