const express = require("express");
const cors = require("cors");
const { con } = require("../../../modal/modal");

const app = express();
const port = 3001;

app.use(express.json());
app.use(cors());

app.get("/productSubCategory", async (req, res) => {
  try {
    const data = "SELECT *from productSubCategory";
    await con.query(data, (err, result) => {
      if (err) {
        return res.send({ error: err.sqlMessage });
      }
      res.json({ status: 200, response: result });
    });
  } catch (err) {
    res.send(err.sqlMessage);
  }
});

app.post("/productSubCategory", async (req, res) => {
  try {
    const data = req.body;
    const q1 = "INSERT into productSubCategory SET ?";
    await con.query(q1, data, (err, result) => {
      if (err) {
        return res.send({ error: err.sqlMessage });
      }
      res.json({ status: 200, response: result });
    });
  } catch (err) {
    res.send(err.sqlMessage);
  }
});

app.patch("/updateproductSubCategory/:ccid", async (req, res) => {
  try {
    const data = req.body;
    const q1 = "UPDATE  productSubCategory SET ? where ccid = ?";

    await con.query(q1, [data, req.params.ccid], (err, result) => {
      if (err) {
        return res.send({ error: err.sqlMessage });
      }
      res.json({ status: 200, response: result });
    });
  } catch (err) {
    res.send(err.sqlMessage);
  }
});

app.delete("/deleteproductSubCategory/:ccid", async (req, res) => {
  try {
    const ccid = req.params.ccid;
    const q1 = "DELETE from productSubCategory where ccid = ?";
    await con.query(q1, ccid, (err, result) => {
      if (err) {
        return res.send({ error: err.sqlMessage });
      }
      res.json({ status: 200, response: result });
    });
  } catch (err) {
    res.send(err.sqlMessage);
  }
});

app.listen(port, () => {
  console.log("server started = http://localhost:3001");
});
