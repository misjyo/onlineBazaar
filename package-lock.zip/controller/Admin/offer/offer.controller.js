const express = require("express");
const cors = require("cors");
const { con } = require("../../../modal/modal");

const app = express();
const port = 3001;

app.use(express.json());
app.use(cors());

app.get("/offer", async (req, res) => {
  try {
    const data = "SELECT *from offer";
    await con.query(data, (err, result) => {
      if (err) {
        return res.send({ error: err.sqlMessage });
      }
      res.json({ status: 200, response: result });
    });
  } catch (err) {
    res.send(err.sqlMessage);
  }
});

app.post("/offer", async (req, res) => {
  try {
    const data = req.body;
    const q1 = "INSERT into offer SET ?";
    await con.query(q1, data, (err, result) => {
      if (err) {
        return res.send({ error: err.sqlMessage });
      }
      res.json({ status: 200, response: result });
    });
  } catch (err) {
    res.send(err.sqlMessage);
  }
});

app.patch("/updateoffer/:offerid", async (req, res) => {
  try {
    const data = req.body;
    const q1 = "UPDATE  offer SET ? where offerid = ?";

    await con.query(q1, [data, req.params.offerid], (err, result) => {
      if (err) {
        return res.send({ error: err.sqlMessage });
      }
      res.json({ status: 200, response: result });
    });
  } catch (err) {
    res.send(err.sqlMessage);
  }
});

app.delete("/deleteOffer/:offerid", async (req, res) => {
  try {
    const offerid = req.params.offerid;
    const q1 = "DELETE from offer where offerid = ?";
    await con.query(q1, offerid, (err, result) => {
      if (err) {
        return res.send({ error: err.sqlMessage });
      }
      res.json({ status: 200, response: result });
    });
  } catch (err) {
    res.send(err.sqlMessage);
  }
});

app.listen(port, () => {
  console.log("server started = http://localhost:3001");
});
