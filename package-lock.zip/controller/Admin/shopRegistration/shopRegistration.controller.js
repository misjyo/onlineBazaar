const { con } = require("../../../modal/modal");

let getdata = async (req, res) => {
  try {
    const data = "SELECT *from shopregistration";
    await con.query(data, (err, result) => {
      if (err) {
        return res.send({ error: err.sqlMessage });
      }
      res.json({ status: 200, response: result });
    });
  } catch (err) {
    res.send(err.sqlMessage);
  }
};

// app.post("/shopregistration", validate, async (req, res) => {
//   try {
//     const data = req.body;
//     const q1 = "INSERT into shopregistration SET ?";
//     await con.query(q1, data, (err, result) => {
//       if (err) {
//         return res.send({ error: err.sqlMessage });
//       }
//       res.json({ status: 200, response: result });
//     });
//   } catch (err) {
//     res.send(err.sqlMessage);
//   }
// });

// app.patch("/updateshop/:shopid", validate, async (req, res) => {
//   try {
//     const data = req.body;
//     const q1 = "UPDATE  shopregistration SET ? where shopid = ?";

//     await con.query(q1, [data, req.params.shopid], (err, result) => {
//       if (err) {
//         return res.send({ error: err.sqlMessage });
//       }
//       res.json({ status: 200, response: result });
//     });
//   } catch (err) {
//     res.send(err.sqlMessage);
//   }
// });

// app.delete("/deleteShop/:shopid", validate, async (req, res) => {
//   try {
//     const shopid = req.params.shopid;
//     const q1 = "DELETE from shopregistration where shopid = ?";
//     await con.query(q1, shopid, (err, result) => {
//       if (err) {
//         return res.send({ error: err.sqlMessage });
//       }
//       res.json({ status: 200, response: result });
//     });
//   } catch (err) {
//     res.send(err.sqlMessage);
//   }
// });


 module.exports = {getdata};