const express = require("express");
const cors = require("cors");
const { con } = require("../../../modal/modal");

const app = express();
const port = 3001;

app.use(express.json());
app.use(cors());

app.get("/addToWhislist", async (req, res) => {
  try {
    const data = "SELECT *from addToWhislist";
    await con.query(data, (err, result) => {
      if (err) {
        return res.send({ error: err.sqlMessage });
      }
      res.json({ status: 200, response: result });
    });
  } catch (err) {
    res.send(err.sqlMessage);
  }
});

app.post("/addToWhislist", async (req, res) => {
  try {
    const data = req.body;
    const q1 = "INSERT into addToWhislist SET ?";
    await con.query(q1, data, (err, result) => {
      if (err) {
        return res.send({ error: err.sqlMessage });
      }
      res.json({ status: 200, response: result });
    });
  } catch (err) {
    res.send(err.sqlMessage);
  }
});

app.patch("/updateaddToWhislist/:pid", async (req, res) => {
  try {
    const data = req.body;
    const q1 = "UPDATE  addToWhislist SET ? where pid = ?";

    await con.query(q1, [data, req.params.pid], (err, result) => {
      if (err) {
        return res.send({ error: err.sqlMessage });
      }
      res.json({ status: 200, response: result });
    });
  } catch (err) {
    res.send(err.sqlMessage);
  }
});

app.delete("/deleteaddToWhislist/:pid", async (req, res) => {
  try {
    const pid = req.params.pid;
    const q1 = "DELETE from addToWhislist where pid = ?";
    await con.query(q1, pid, (err, result) => {
      if (err) {
        return res.send({ error: err.sqlMessage });
      }
      res.json({ status: 200, response: result });
    });
  } catch (err) {
    res.send(err.sqlMessage);
  }
});

app.listen(port, () => {
  console.log("server started = http://localhost:3001");
});
