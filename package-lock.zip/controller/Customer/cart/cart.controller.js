const express = require("express");
const cors = require("cors");
const { con } = require("../../../modal/modal");

const app = express();
const port = 3001;

app.use(express.json());
app.use(cors());

app.get("/cart", async (req, res) => {
  try {
    const data = "SELECT *from cart";
    await con.query(data, (err, result) => {
      if (err) {
        return res.send({ error: err.sqlMessage });
      }
      res.json({ status: 200, response: result });
    });
  } catch (err) {
    res.send(err.sqlMessage);
  }
});

app.post("/cart", async (req, res) => {
  try {
    const data = req.body;
    const q1 = "INSERT into cart SET ?";
    await con.query(q1, data, (err, result) => {
      if (err) {
        return res.send({ error: err.sqlMessage });
      }
      res.json({ status: 200, response: result });
    });
  } catch (err) {
    res.send(err.sqlMessage);
  }
});

app.patch("/updatecart/:cartid", async (req, res) => {
  try {
    const data = req.body;
    const q1 = "UPDATE  cart SET ? where cartid = ?";

    await con.query(q1, [data, req.params.cartid], (err, result) => {
      if (err) {
        return res.send({ error: err.sqlMessage });
      }
      res.json({ status: 200, response: result });
    });
  } catch (err) {
    res.send(err.sqlMessage);
  }
});

app.delete("/deletecart/:cartid", async (req, res) => {
  try {
    const cartid = req.params.cartid;
    const q1 = "DELETE from cart where cartid = ?";
    await con.query(q1, cartid, (err, result) => {
      if (err) {
        return res.send({ error: err.sqlMessage });
      }
      res.json({ status: 200, response: result });
    });
  } catch (err) {
    res.send(err.sqlMessage);
  }
});

app.listen(port, () => {
  console.log("server started = http://localhost:3001");
});
