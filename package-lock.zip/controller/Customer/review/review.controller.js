const express = require("express");
const cors = require("cors");
const { con } = require("../../../modal/modal");

const app = express();
const port = 3001;

app.use(express.json());
app.use(cors());

app.get("/review", async (req, res) => {
  try {
    const data = "SELECT *from review";
    await con.query(data, (err, result) => {
      if (err) {
        return res.send({ error: err.sqlMessage });
      }
      res.json({ status: 200, response: result });
    });
  } catch (err) {
    res.send(err.sqlMessage);
  }
});

app.post("/review", async (req, res) => {
  try {
    const data = req.body;
    const q1 = "INSERT into review SET ?";
    await con.query(q1, data, (err, result) => {
      if (err) {
        return res.send({ error: err.sqlMessage });
      }
      res.json({ status: 200, response: result });
    });
  } catch (err) {
    res.send(err.sqlMessage);
  }
});

app.patch("/updatereview/:cid", async (req, res) => {
  try {
    const data = req.body;
    const q1 = "UPDATE  review SET ? where cid = ?";

    await con.query(q1, [data, req.params.cid], (err, result) => {
      if (err) {
        return res.send({ error: err.sqlMessage });
      }
      res.json({ status: 200, response: result });
    });
  } catch (err) {
    res.send(err.sqlMessage);
  }
});

app.delete("/deletereview/:cid", async (req, res) => {
  try {
    const cid = req.params.cid;
    const q1 = "DELETE from review where cid = ?";
    await con.query(q1, cid, (err, result) => {
      if (err) {
        return res.send({ error: err.sqlMessage });
      }
      res.json({ status: 200, response: result });
    });
  } catch (err) {
    res.send(err.sqlMessage);
  }
});

app.listen(port, () => {
  console.log("server started = http://localhost:3001");
});
